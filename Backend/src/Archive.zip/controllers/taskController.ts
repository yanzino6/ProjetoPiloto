import { Request, Response } from 'express';
import { createTask, getTasksByUser, updateTask, deleteTask } from '../models/modelTasks';
import { getUserByEmail } from '../models/modelUser';
import { createToken } from '../jwt/jwt';


export const createTaskController = async (req: Request, res: Response) => {
    try {
        const newTask = await createTask(req.body);
        const user = await getUserByEmail(req.body);
        newTask.user_id = user.id;
        res.status(201).json(newTask);
    } catch (error) {
        res.status(500).json({ message: 'Error creating task' });
    }
};


export const getTasksController = async (req: Request, res: Response) => {
    try {
        const userId = req.body.userId; 
        const tasks = await getTasksByUser(userId);
        res.json(tasks);
    } catch (error) {
        res.status(500).json({ message: 'Error getting tasks' });
    }
};


export const updateTaskController = async (req: Request, res: Response) => {
    try {
        const updatedTask = await updateTask(parseInt(req.params.id), req.body);
        res.json(updatedTask);
    } catch (error) {
        res.status(500).json({ message: 'Error updating task' });
    }
};


export const deleteTaskController = async (req: Request, res: Response) => {
    try {
        await deleteTask(parseInt(req.params.id));
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ message: 'Error deleting task' });
    }
};

