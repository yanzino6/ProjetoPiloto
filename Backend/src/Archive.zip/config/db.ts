import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config(); 

const pool = new Pool({
    user: process.env.DB_USER,           // Usuário do banco de dados
    host: process.env.DB_HOST,           // Endereço do banco de dados
    database: process.env.DB_NAME,       // Nome do banco de dados
    password: process.env.DB_PASSWORD,   // Senha do banco de dados
    port: parseInt(process.env.DB_PORT || '5432'), // Porta do banco de dados (padrão 5432 para PostgreSQL)
});

const connect = async () => {
    const client = await pool.connect();
    return client;
}


const close = async () => {
    await pool.end();
}


export { pool, connect, close };