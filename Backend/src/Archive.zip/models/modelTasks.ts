
import { connect } from "../config/db";

export interface Task {
    id: number;
    label: string;
    categorie: string;
    user_id: number;
    done: boolean;
}


export async function createTask(task: Task) {
    const client = await connect();
    const res = await client.query('INSERT INTO tasks (label, categorie, done, user_id) VALUES ($1, $2, $3, $4) RETURNING *',
        [task.label, task.categorie, task.done, task.user_id]);
    return res.rows[0];
}


export async function getTasksByUser(userId: number) {
    const client = await connect();
    const res = await client.query('SELECT * FROM tasks WHERE user_id = $1', [userId]);
    return res.rows;
}


export async function updateTask(id: number, task: Task) {
    const client = await connect();
    const res = await client.query('UPDATE tasks SET label = $1, categorie = $2, done = $3 WHERE id = $4 AND user_id = $5 RETURNING *',
        [task.label, task.categorie, task.done, id, task.user_id]);
    return res.rows[0];
}


export async function deleteTask(id: number) {
    const client = await connect();
    await client.query('DELETE FROM tasks WHERE id = $1', [id]);
}