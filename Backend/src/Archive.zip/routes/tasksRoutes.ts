import { Router } from 'express';
import { createTaskController, getTasksController, updateTaskController, deleteTaskController } from '../controllers/taskController';
import { checkToken } from '../middlewares/authMiddleware';

const router = Router();


router.post('/', checkToken, createTaskController);


router.get('/:user_id', checkToken, getTasksController);


router.patch('/:id', checkToken, updateTaskController);


router.delete('/:id', checkToken, deleteTaskController);

export default router;