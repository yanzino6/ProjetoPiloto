import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '../jwt/jwt';

export const checkToken = (
    req: Request,
    res: Response,
    next: NextFunction
): void => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        res.status(401).json({ error: 'Token required' });
        return;
    }

    const token = authHeader.split(' ')[1]; 

    if (!verifyToken(token)) {
        res.status(401).send({ error: "Unauthorized" });
        return;
    }

    next();
};