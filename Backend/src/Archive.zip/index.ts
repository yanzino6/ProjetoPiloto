import express from "express"
import userRoutes from './routes/usersRoutes'
import taskRoutes from './routes/tasksRoutes'
const app = express()

const db = require("./config/db")

app.use(express.json())

app.use('/api/users', userRoutes);
app.use('/tasks', taskRoutes);

app.listen({
    port: 3000,
    host: '0.0.0.0'
})

console.log("Server running on port 3000")