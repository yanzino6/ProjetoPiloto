import React from 'react'
import RoutesApp from '../../routes'

const System = () => {
  return (
    <>
      <RoutesApp />
    </>
  )
}

export default System