import LoginForms from "../../components/LoginForms";


export function Login() {
    return <div className="">
        <div className="">
            <LoginForms />
        </div>
    </div>


}

