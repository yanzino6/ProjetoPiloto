import SignUpForm from "../../components/SignUpForm";


export function Signup() {
    return <div>
        <SignUpForm />
    </div>
}